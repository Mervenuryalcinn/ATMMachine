import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ATMMachine atmMachine = new ATMMachine(1000); // ATM 1000 birim nakit ile başlar
        boolean exit = false;

        while (!exit) {
            if (atmMachine.isBlocked()) {
                System.out.println("\nKartınız bloke edilmiş. Lütfen müşteri hizmetleri ile iletişime geçin.");
                break; // Kart bloke edilirse tüm işlemleri sonlandır
            }
            System.out.println("\nATM İşlemleri:");
            System.out.println("1. Kart Tak");
            System.out.println("2. Kart Çıkar");
            System.out.print("Seçiminizi yapın (1-2): ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    atmMachine.insertCard();
                    // Kart takıldıktan sonra şifre istemek için kontrol
                    System.out.print("Şifreyi girin: ");
                    int pin = scanner.nextInt();
                    atmMachine.enterPin(pin); // Nesne üzerinden enterPin çağrılıyor

                    // Eğer şifre doğruysa ATM işlemlerini sun
                    if (atmMachine.getCurrentState() instanceof HasCorrectPinState) {
                        boolean atmOperations = true;

                        while (atmOperations) {
                            if (atmMachine.isBlocked()) {
                                System.out.println("\nKartınız bloke edilmiş. Lütfen müşteri hizmetleri ile iletişime geçin.");
                                atmOperations = false; // İşlemleri sonlandır
                                break;
                            }
                            System.out.println("\nATM İşlemleri:");
                            System.out.println("1. Nakit Çek");
                            System.out.println("2. Nakit Yatır");
                            System.out.println("3. Bakiye Sorgula");
                            System.out.println("4. Kredi Kartı İşlemleri");
                            System.out.println("5. Kart Çıkar");
                            System.out.println("6. Çıkış");
                            System.out.print("Seçiminizi yapın (1-6): ");

                            int operationChoice = scanner.nextInt();

                            switch (operationChoice) {
                                case 1:
                                    System.out.print("Çekmek istediğiniz miktarı girin: ");
                                    int withdrawAmount = scanner.nextInt();
                                    atmMachine.withdrawCash(withdrawAmount);
                                    break;
                                case 2:
                                    System.out.print("Yatırmak istediğiniz miktarı girin: ");
                                    int depositAmount = scanner.nextInt();
                                    atmMachine.depositCash(depositAmount);
                                    break;
                                case 3:
                                    atmMachine.checkBalance();
                                    break;

                                case 4:
                                    atmMachine.processCreditCard();
                                    break;
                                case 5:
                                    atmMachine.ejectCard();
                                    atmOperations = false; // Kart çıkarıldığında işlemleri sonlandır
                                    break;
                                case 6:
                                    atmOperations = false; // Çıkış yap
                                    exit = true;
                                    System.out.println("Çıkış yapılıyor...");
                                    break;
                                default:
                                    System.out.println("Geçersiz seçim. Lütfen 1-6 arasında bir sayı girin.");
                            }
                        }
                    } else {
                        System.out.println("Şifre hatalı. Lütfen kartı yeniden takın ve tekrar deneyin.");
                    }
                    break;

                case 2:
                    atmMachine.ejectCard();
                    break;

                default:
                    System.out.println("Geçersiz seçim. Lütfen 1-2 arasında bir sayı girin.");
            }
        }

        scanner.close();
    }
}
