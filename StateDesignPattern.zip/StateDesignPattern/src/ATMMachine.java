public class ATMMachine {

    private ATMState noCardState;
    private ATMState hasCardState;
    private ATMState hasCorrectPinState;



    private ATMState currentState;
    private int cash;
    private CreditCard creditCard;
    private boolean isBlocked = false; // Kartın bloklanma durumu
    private int pinAttemptCounter = 0; // Şifre deneme sayacı

    public ATMMachine(int initialCash) {

        noCardState = new NorCardState(this);
        hasCardState = new HasCardState(this);
        hasCorrectPinState = new HasCorrectPinState(this);


        currentState = noCardState;
        cash = initialCash;
        creditCard = new CreditCard(5000);
    }

    public void setState(ATMState state) {
        currentState = state;
    }

    public ATMState getNoCardState() {
        return noCardState;
    }

    public ATMState getHasCardState() {
        return hasCardState;
    }
    public ATMState getCurrentState() {
        return currentState;
    }
    public ATMState getHasCorrectPinState() {
        return hasCorrectPinState;
    }

    public int getCash() {
        return cash;
    }

    public void setCash(int cash) {
        this.cash = cash;
    }
    public CreditCard getCreditCard() {
        return creditCard;
    }
    public boolean isBlocked() {
        return isBlocked;
    }
    public void insertCard() {
        if (isBlocked) {
            System.out.println("Kartınız bloke edilmiş. Lütfen müşteri hizmetleri ile iletişime geçin.");
        } else {
            currentState.insertCard();
        }
       // currentState.insertCard();
    }

    public void ejectCard() {
        if (!isBlocked) {
            currentState.ejectCard();
            resetPinAttempts();
        } else {
            System.out.println("Kartınız bloke edilmiş. Lütfen müşteri hizmetleri ile iletişime geçin.");
        }
        //currentState.ejectCard();
    }


    public void enterPin(int pin) {
        if (isBlocked) {
            System.out.println("Kartınız bloke edilmiş. Lütfen müşteri hizmetleri ile iletişime geçin.");
            return;
        }

        if (pin == 2828) { // Doğru şifre kontrolü
            System.out.println("Şifre doğru. Hoş geldiniz!");
            pinAttemptCounter = 0; // Sayacı sıfırla
            currentState.enterPin(pin);
        } else {
            pinAttemptCounter++; // Yanlış deneme sayısını artır
            System.out.println("Hatalı şifre. Kalan deneme hakkı: " + (3 - pinAttemptCounter));
            if (pinAttemptCounter >= 3) {
                isBlocked = true; // Kartı bloke et
                System.out.println("3 kez hatalı şifre girdiniz. Kartınız bloke edilmiştir.");
            }
        }
        //currentState.enterPin(pin);
    }

    public void withdrawCash(int amount) {
        if (!isBlocked) {
            currentState.withdrawCash(amount);
        } else {
            System.out.println("Kartınız bloke edilmiş. İşlem yapılamıyor.");
        }

        //currentState.withdrawCash(amount);
    }

    public void depositCash(int amount) {
        if (!isBlocked) {
            currentState.depositCash(amount);
        } else {
            System.out.println("Kartınız bloke edilmiş. İşlem yapılamıyor.");
        }
        //currentState.depositCash(amount);
    }

    public void checkBalance() {
        if (!isBlocked) {
            System.out.println("Hesabınızdaki bakiye: " + cash + " TL.");
            currentState.checkBalance();
        } else {
            System.out.println("Kartınız bloke edilmiş. İşlem yapılamıyor.");
        }
        // System.out.println("Hesabınızdaki bakiye: " + cash + " TL.");

    }

    public void makePayment() {
        System.out.println("Ödeme işlemi yapılıyor...");
        currentState.makePayment();

    }
    public void resetPinAttempts() {
        pinAttemptCounter = 0; // Kart çıkarıldığında sayacı sıfırla
    }
    public void processCreditCard() {
        currentState.processCreditCard();
    }

    public void selectOperation() {
        currentState.selectOperation();
    }

}
