import java.util.Scanner;
public class HasCorrectPinState implements ATMState{

    private ATMMachine atmMachine;

    public HasCorrectPinState(ATMMachine atmMachine) {
        this.atmMachine = atmMachine;
    }

    @Override
    public void insertCard() {
        System.out.println("Kart zaten takılmış durumda.");
    }

    @Override
    public void ejectCard() {
        System.out.println("Kart çıkarıldı.");
        atmMachine.setState(atmMachine.getNoCardState());
    }

    @Override
    public void enterPin(int pin) {
        System.out.println("Şifre zaten girildi.");
    }

    @Override
    public void withdrawCash(int amount) {

        if (amount <= atmMachine.getCash()) {
            System.out.println("Çekilen nakit miktarı: " + amount);
            atmMachine.setCash(atmMachine.getCash() - amount);
            System.out.println("Hesapta kalan bakiye: " + atmMachine.getCash());

            if (atmMachine.getCash() <= 0) {
                System.out.println("ATM'de para kalmadı.");
                atmMachine.setState(atmMachine.getNoCardState());
            }
        }else {
            System.out.println("ATM'de yeterince nakit bulunmamamktadır.");
        }

    }
    @Override
    public void depositCash(int amount) {
        atmMachine.setCash(atmMachine.getCash() + amount);
        System.out.println("Yatırılan miktar: " + amount);
        System.out.println("Hesapta kalan bakiye: " + atmMachine.getCash());
    }

    @Override
    public void checkBalance() {
        System.out.println("Hesap bakiyesi: " + atmMachine.getCash());
    }
    @Override
    public void makePayment() {
        System.out.println("Ödeme işlemi başlatılıyor...");
        // Ödeme işlemi gerçekleştirilir
    }

    @Override
    public void processCreditCard() {
        System.out.println("Kredi kartı işlemleri başlatılıyor...");
        // Kredi kartı işlemleri yapılır

        boolean creditCardOperations = true;

        while (creditCardOperations) {
            System.out.println("\nKredi Kartı İşlemleri:");
            System.out.println("1. Borcunu Sorgula");
            System.out.println("2. Borç Ödeme");
            System.out.println("3. Limit Artırma");
            System.out.println("4. Geri");
            System.out.print("Seçiminizi yapın (1-4): ");

            Scanner scanner = new Scanner(System.in);
            int operationChoice = scanner.nextInt();

            switch (operationChoice) {
                case 1:
                    atmMachine.getCreditCard().checkBalance();
                    break;
                case 2:
                    System.out.print("Ödenecek tutarı girin: ");
                    double paymentAmount = scanner.nextDouble();
                    atmMachine.getCreditCard().makePayment(paymentAmount);
                    break;
                case 3:
                    System.out.print("Artırmak istediğiniz limiti girin: ");
                    double limitIncrease = scanner.nextDouble();
                    atmMachine.getCreditCard().increaseLimit(limitIncrease);
                    break;
                case 4:
                    creditCardOperations = false; // Geri dön
                    break;
                default:
                    System.out.println("Geçersiz seçim.");
            }
        }
    }
    @Override
    public void selectOperation() {
        System.out.println("Yapmak istediğiniz işlemi seçin:");
        System.out.println("1. Bakiye Sorgulama");
        System.out.println("2. Nakit Çekme");
        System.out.println("3. Nakit Yatırma");
        System.out.println("4. Ödeme Yap");
        System.out.println("5. Kredi Kartı İşlemleri");
        System.out.println("6. Çıkış");
    }
}

