
public class CreditCard {
    private double limit;
    private double balance;

    public CreditCard(double limit) {
        this.limit = limit;
        this.balance = 350;  // Başlangıçta borç 350
    }

    public double getLimit() {
        return limit;
    }

    public void setLimit(double limit) {
        this.limit = limit;
    }

    public double getBalance() {
        return balance;
    }

    public void makePayment(double amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println(amount + " birim ödeme yapıldı. Kalan borç: " + balance);
        } else {
            System.out.println("Ödeme tutarı borcunuzdan büyük.");
        }
    }

    public void increaseLimit(double amount) {
        limit += amount;
        System.out.println("Limit başarıyla artırıldı. Yeni limit: " + limit);
    }

    public void checkBalance() {
        System.out.println("Mevcut borcunuz: " + balance + " TL.");
    }
}
